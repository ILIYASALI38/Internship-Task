from django.contrib import admin
from .models import Problem, SolutionStep

@admin.register(Problem)
class ProblemAdmin(admin.ModelAdmin):
    list_display = ['title', 'category', 'template_type', 'created_at']
    list_filter = ['category', 'template_type', 'created_at']
    search_fields = ['title', 'problem_statement']
    readonly_fields = ['created_at', 'updated_at']

@admin.register(SolutionStep)
class SolutionStepAdmin(admin.ModelAdmin):
    list_display = ['problem', 'step_number', 'description']
    list_filter = ['problem__category']