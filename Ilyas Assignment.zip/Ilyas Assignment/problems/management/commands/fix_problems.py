from django.core.management.base import BaseCommand
from problems.models import Problem

class Command(BaseCommand):
    help = 'Fix problem data and ensure template types match'
    
    def handle(self, *args, **options):
        self.stdout.write('Checking and fixing problems...')
        
        problems = Problem.objects.all()
        for problem in problems:
            self.stdout.write(f'Problem {problem.id}: {problem.title}')
            self.stdout.write(f'  Category: {problem.category}')
            self.stdout.write(f'  Template: {problem.template_type}')
            
            # Fix template type based on category
            if problem.category == 'trigonometry' and problem.template_type != 'trigonometry':
                problem.template_type = 'trigonometry'
                problem.save()
                self.stdout.write(f'  ✓ Fixed template type to trigonometry')
            
            elif problem.category in ['simple_interest', 'compound_interest'] and problem.template_type != 'compound_interest':
                problem.template_type = 'compound_interest'
                problem.save()
                self.stdout.write(f'  ✓ Fixed template type to compound_interest')
        
        self.stdout.write(self.style.SUCCESS('✓ All problems checked and fixed'))
