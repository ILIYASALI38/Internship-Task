from django.core.management.base import BaseCommand
from problems.models import Problem

class Command(BaseCommand):
    help = 'Create sample problems with correct template types'
    
    def handle(self, *args, **options):
        # Clear existing problems
        Problem.objects.all().delete()
        
        # Create trigonometry problems
        Problem.objects.create(
            title='Pythagorean Triplet - 7, 24, 25',
            category='trigonometry',
            template_type='trigonometry',
            problem_statement='In a right triangle with sides 7, 24, 25, find Sec C + Cot A',
            solution_data={
                'side_a': 7,
                'side_b': 24,
                'side_c': 25,
                'sec_c': '25/24',
                'cot_a': '7/24',
                'final_answer': '4/3'
            }
        )
        
        Problem.objects.create(
            title='Pythagorean Triplet - 5, 12, 13',
            category='trigonometry',
            template_type='trigonometry',
            problem_statement='In a right triangle with sides 5, 12, 13, find Sin A + Cos B',
            solution_data={
                'side_a': 5,
                'side_b': 12,
                'side_c': 13,
                'sin_a': '5/13',
                'cos_b': '5/13',
                'final_answer': '10/13'
            }
        )
        
        # Create compound interest problems
        Problem.objects.create(
            title='Rate Calculation - 3 years CI',
            category='compound_interest',
            template_type='compound_interest',
            problem_statement='₹12000 amounts to ₹20736 in 3 years at CI. Find rate.',
            solution_data={
                'principal': 12000,
                'amount': 20736,
                'time': 3,
                'rate': 20,
                'amount_2_years': 17280,
                'fraction_simplified': {'num': 6, 'den': 5},
                'cube_root': {'num_cube': 216, 'den_cube': 125}
            }
        )
        
        Problem.objects.create(
            title='Amount Calculation - 2 years CI',
            category='compound_interest',
            template_type='compound_interest',
            problem_statement='Find CI on ₹8000 for 2 years at 15% per annum compounded annually',
            solution_data={
                'principal': 8000,
                'amount': 10580,
                'time': 2,
                'rate': 15,
                'amount_2_years': 10580,
                'fraction_simplified': {'num': 23, 'den': 20},
                'cube_root': {'num_cube': 529, 'den_cube': 400}
            }
        )
        
        self.stdout.write(self.style.SUCCESS('✓ Created 4 sample problems with correct template types'))