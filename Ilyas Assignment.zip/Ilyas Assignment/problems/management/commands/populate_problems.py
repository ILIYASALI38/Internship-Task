from django.core.management.base import BaseCommand
from problems.models import Problem

class Command(BaseCommand):
    help = 'Populate database with sample problems'
    
    def handle(self, *args, **options):
        # Trigonometry problems
        Problem.objects.get_or_create(
            title='Pythagorean Triplet - Sec C + Cot A',
            category='trigonometry',
            template_type='trigonometry',
            problem_statement='In a right triangle with sides 7, 24, 25, find Sec C + Cot A',
            solution_data={
                'side_a': 7,
                'side_b': 24,
                'side_c': 25,
                'sec_c': '25/24',
                'cot_a': '7/24',
                'final_answer': '4/3'
            }
        )
        
        Problem.objects.get_or_create(
            title='Triangle with sides 5, 12, 13',
            category='trigonometry',
            template_type='trigonometry',
            problem_statement='Find Sin A + Cos B in a right triangle with sides 5, 12, 13',
            solution_data={
                'side_a': 5,
                'side_b': 12,
                'side_c': 13,
                'sin_a': '5/13',
                'cos_b': '5/13',
                'final_answer': '10/13'
            }
        )
        
        # Compound Interest problems
        Problem.objects.get_or_create(
            title='Rate Calculation - 3 years compound interest',
            category='compound_interest',
            template_type='compound_interest',
            problem_statement='₹12000 amounts to ₹20736 in 3 years at CI. Find rate.',
            solution_data={
                'principal': 12000,
                'amount': 20736,
                'time': 3,
                'rate': 20,
                'amount_2_years': 17280
            }
        )
        
        Problem.objects.get_or_create(
            title='Amount calculation with given rate',
            category='compound_interest',
            template_type='compound_interest',
            problem_statement='Find CI on ₹8000 for 2 years at 15% per annum compounded annually',
            solution_data={
                'principal': 8000,
                'amount': 10580,
                'time': 2,
                'rate': 15,
                'compound_interest': 2580
            }
        )
        
        self.stdout.write(self.style.SUCCESS('Successfully populated problems'))