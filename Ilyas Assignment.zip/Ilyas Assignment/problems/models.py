from django.db import models

class Problem(models.Model):
    TEMPLATE_CHOICES = [
        ('trigonometry', 'Trigonometry Template'),
        ('compound_interest', 'Compound Interest Template'),
    ]
    
    CATEGORY_CHOICES = [
        ('trigonometry', 'Trigonometry'),
        ('simple_interest', 'Simple Interest'),
        ('compound_interest', 'Compound Interest'),
    ]
    
    title = models.CharField(max_length=200)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    template_type = models.CharField(max_length=20, choices=TEMPLATE_CHOICES)
    problem_statement = models.TextField()
    solution_data = models.JSONField(default=dict)  # Store dynamic data for templates
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.title
    
    class Meta:
        ordering = ['-created_at']

class SolutionStep(models.Model):
    problem = models.ForeignKey(Problem, on_delete=models.CASCADE, related_name='steps')
    step_number = models.IntegerField()
    description = models.TextField()
    formula = models.CharField(max_length=500, blank=True)
    result = models.CharField(max_length=200, blank=True)
    
    class Meta:
        ordering = ['step_number']