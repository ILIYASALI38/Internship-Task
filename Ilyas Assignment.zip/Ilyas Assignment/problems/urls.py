from django.urls import path
from . import views

app_name = 'problems'

urlpatterns = [
    path('', views.HomeView.as_view(), name='home'),
    path('problems/', views.ProblemListView.as_view(), name='problem_list'),
    
    # Demo pages (no problem_id)
    path('trigonometry/', views.TrigonometryProblemView.as_view(), name='trigonometry_demo'),
    path('compound-interest/', views.CompoundInterestProblemView.as_view(), name='compound_interest_demo'),
    
    # Specific problem pages (with problem_id)
    path('trigonometry/<int:problem_id>/', views.TrigonometryProblemView.as_view(), name='trigonometry_problem'),
    path('compound-interest/<int:problem_id>/', views.CompoundInterestProblemView.as_view(), name='compound_interest_problem'),
    
    # Other pages
    path('create/', views.CreateProblemView.as_view(), name='create_problem'),
    path('api/problem/<int:problem_id>/', views.get_problem_data, name='problem_data_api'),
    
    # Debug endpoint
    path('debug/<int:problem_id>/', views.DebugProblemView.as_view(), name='debug_problem'),
]
