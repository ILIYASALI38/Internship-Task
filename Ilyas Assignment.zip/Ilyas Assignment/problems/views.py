from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.views import View
from django.views.generic import ListView
from django.contrib import messages
from .models import Problem
import json

class HomeView(View):
    def get(self, request):
        problems = Problem.objects.all()[:6]  # Latest 6 problems
        return render(request, 'index.html', {'problems': problems})

class ProblemListView(ListView):
    model = Problem
    template_name = 'problem_list.html'
    context_object_name = 'problems'
    paginate_by = 10

class TrigonometryProblemView(View):
    def get(self, request, problem_id=None):
        if problem_id:
            # Get specific problem and ENSURE it's trigonometry template
            problem = get_object_or_404(Problem, id=problem_id)
            
            # IMPORTANT: Check if problem matches template type
            if problem.template_type != 'trigonometry':
                messages.error(request, f'Problem #{problem_id} is not a trigonometry problem.')
                return redirect('problems:home')
            
            context = {
                'problem': problem,
                'solution_data': problem.solution_data
            }
        else:
            # Default demo problem data
            context = {
                'problem': {
                    'title': 'Pythagorean Triplet Problem',
                    'problem_statement': 'Find Sec C + Cot A for a right triangle with sides 7, 24, 25'
                },
                'solution_data': {
                    'side_a': 7,
                    'side_b': 24,
                    'side_c': 25,
                    'angle_a': 'A',
                    'angle_c': 'C',
                    'sec_c': '25/24',
                    'cot_a': '7/24',
                    'final_answer': '4/3'
                }
            }
        
        return render(request, 'trigonometry_template.html', context)

class CompoundInterestProblemView(View):
    def get(self, request, problem_id=None):
        if problem_id:
            # Get specific problem and ENSURE it's compound interest template
            problem = get_object_or_404(Problem, id=problem_id)
            
            # IMPORTANT: Check if problem matches template type
            if problem.template_type != 'compound_interest':
                messages.error(request, f'Problem #{problem_id} is not a compound interest problem.')
                return redirect('problems:home')
            
            context = {
                'problem': problem,
                'solution_data': problem.solution_data
            }
        else:
            # Default demo problem data
            context = {
                'problem': {
                    'title': 'Compound Interest Rate Calculation',
                    'problem_statement': 'A sum of ₹12000 amounts to ₹20736 in 3 years at compound interest. Find the rate.'
                },
                'solution_data': {
                    'principal': 12000,
                    'amount': 20736,
                    'time': 3,
                    'rate': 20,
                    'amount_2_years': 17280,
                    'fraction_simplified': {'num': 6, 'den': 5},
                    'cube_root': {'num_cube': 216, 'den_cube': 125}
                }
            }
        
        return render(request, 'compound_interest_template.html', context)

class CreateProblemView(View):
    def get(self, request):
        return render(request, 'create_problem.html')
    
    def post(self, request):
        try:
            data = json.loads(request.body)
            
            # Validate template_type and category match
            template_type = data.get('template_type')
            category = data.get('category')
            
            # Validation rules
            if template_type == 'trigonometry' and category != 'trigonometry':
                return JsonResponse({
                    'success': False, 
                    'error': 'Trigonometry template can only be used with trigonometry category'
                })
            
            if template_type == 'compound_interest' and category not in ['simple_interest', 'compound_interest']:
                return JsonResponse({
                    'success': False, 
                    'error': 'Compound interest template can only be used with interest-related categories'
                })
            
            problem = Problem.objects.create(
                title=data.get('title'),
                category=category,
                template_type=template_type,
                problem_statement=data.get('problem_statement'),
                solution_data=data.get('solution_data', {})
            )
            
            return JsonResponse({
                'success': True, 
                'problem_id': problem.id,
                'message': 'Problem created successfully',
                'redirect_url': f'/{template_type}/{problem.id}/' if template_type else '/'
            })
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

def get_problem_data(request, problem_id):
    """API endpoint to get problem data in JSON format"""
    problem = get_object_or_404(Problem, id=problem_id)
    return JsonResponse({
        'id': problem.id,
        'title': problem.title,
        'category': problem.category,
        'template_type': problem.template_type,
        'problem_statement': problem.problem_statement,
        'solution_data': problem.solution_data,
        'created_at': problem.created_at.isoformat()
    })

# NEW VIEW: Debug view to check problem data
class DebugProblemView(View):
    def get(self, request, problem_id):
        problem = get_object_or_404(Problem, id=problem_id)
        return JsonResponse({
            'problem_id': problem.id,
            'title': problem.title,
            'category': problem.category,
            'template_type': problem.template_type,
            'solution_data': problem.solution_data,
            'expected_template': f'{problem.template_type}_template.html'
        })